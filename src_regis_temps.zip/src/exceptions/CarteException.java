package exceptions;

public class CarteException extends Exception {
	private static final long serialVersionUID = 1L;

	public CarteException(String message) {
		super(message);
	}
}
